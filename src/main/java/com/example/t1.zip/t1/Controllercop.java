package com.example.t1;

import java.net.URL;
import java.util.ResourceBundle;

public interface Controllercop {
    void initialize(URL url, ResourceBundle resourceBundle);
}
