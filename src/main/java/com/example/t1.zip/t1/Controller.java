package com.example.t1;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    public ObservableList<Integer> num;
    private ComboBox cmbx1;

    public TextField tf1;

    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @FXML
    void add(ActionEvent event) {
        String s = cmbx1.getSelectionModel().getSelectedItem().toString();
        welcomeText.setText(s);

    }

    public ComboBox getCmbx1() {
        return cmbx1;
    }

    public void setCmbx1(ComboBox cmbx1) {
        this.cmbx1 = cmbx1;
    }

    public void handleBtnOK(ActionEvent actionEvent){

    }
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        cmbx1.getItems().add("Item 4");
        cmbx1.getItems().add("Item 4");
        cmbx1.getItems().add("Item 4");


    }
}
